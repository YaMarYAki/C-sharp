﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace StudentApi.Controllers
{
    [ApiController]
    [Route("api/students")]
    public class StudentsController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetStudents()
        {
            var students = new List<object>
            {
                new
                {
                    id = 1,
                    name = "Маркидонов",
                    grades = new List<object>
                    {
                        new { subject = "ИСиТ", grade = 5 }
                        
                    }
                },
                new
                {
                    id = 2,
                    name = "Федорков",
                    grades = new List<object>
                    {
                        new { subject = "МО", grade = 3 }
                       
                    }
                }
            };

            return Ok(students);
        }
    }
}
