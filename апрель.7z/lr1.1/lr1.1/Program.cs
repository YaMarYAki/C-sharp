﻿using System;
using System.Threading;

class Program
{
    static void Main()
    {
        Thread potok1 = new Thread(() => Print(1, 5));
        potok1.Start();

        Thread potok2 = new Thread(() => Print(10, 15));
        potok2.Start();

        potok1.Join();
        potok2.Join();

        Console.WriteLine("Потоки завершили выполнение");
    }

    static void Print(int start, int end)
    {
        for (int i = start; i <= end; i++)
        {
            Console.WriteLine($"Поток {Thread.CurrentThread.ManagedThreadId}: {i}");
            Thread.Sleep(200);
        }
    }
}