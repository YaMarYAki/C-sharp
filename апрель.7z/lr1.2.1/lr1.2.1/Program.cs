﻿using System;
using System.Threading;

class Program
{
    private static bool First = false;

    static void Main()
    {
        Console.WriteLine("=== Без задержки между запуском потоков ===");
        RunExperiment(false);        
    }
    static void RunExperiment(bool addDelay)
    {
        First = false;
        Thread thread1 = new Thread(() =>
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine($"Поток 1: {i}");
                Thread.Sleep(10);
            }
            First = true;
        });

        Thread thread2 = new Thread(() =>
        {
            while (!First)
            {
                Thread.Sleep(10); 
            }
            for (int i = 101; i <= 200; i++)
            {
                Console.WriteLine($"Поток 2: {i}");
                Thread.Sleep(10);
            }
        });
        thread1.Start();
        thread2.Start();
        thread1.Join();
        thread2.Join();
    }
}