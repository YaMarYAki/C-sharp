﻿using System;
using System.Threading;

class Program
{
    private static readonly ManualResetEventSlim first = new ManualResetEventSlim(false);
    private static readonly object Lock = new object();

    static void Main()
    {
        Thread thread1 = new Thread(() =>
        {
            for (int i = 1; i <= 100; i++)
            {
                lock (Lock)
                {
                    Console.WriteLine($"Поток 1: {i}");
                }
                Thread.Sleep(10);
            }
            first.Set(); 
        });
        Thread thread2 = new Thread(() =>
        {
            first.Wait(); 
            for (int i = 101; i <= 200; i++)
            {
                lock (Lock)
                {
                    Console.WriteLine($"Поток 2: {i}");
                }
                Thread.Sleep(10);
            }
        });
        thread1.Start();
        Thread.Sleep(2000); 
        thread2.Start();
        thread1.Join();
        thread2.Join();
    }
}