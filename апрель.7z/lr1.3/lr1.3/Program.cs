﻿using System;
using System.Threading;

class Program
{
    private static double value = 0.5; 
    private static readonly object sync = new object();
    private static bool isCosTurn = true; 

    static void Main()
    {
        Thread cosThread = new Thread(CalculateCos);
        Thread acosThread = new Thread(CalculateAcos);

        cosThread.Start();
        acosThread.Start();

        cosThread.Join();
        acosThread.Join();
    }
    static void CalculateCos()
    {
        while (true)
        {
            lock (sync)
            {
                if (!isCosTurn)
                {
                    Monitor.Wait(sync); 
                }
                value = Math.Cos(value);
                Console.WriteLine($"Косинус: {value}");
                isCosTurn = false;
                Monitor.Pulse(sync); 
            }
            Thread.Sleep(500); 
        }
    }

    static void CalculateAcos()
    {
        while (true)
        {
            lock (sync)
            {
                if (isCosTurn)
                {
                    Monitor.Wait(sync); 
                }
                double safeValue = Math.Max(-1, Math.Min(1, value));
                value = Math.Acos(safeValue);
                Console.WriteLine($"Арккосинус: {value}");
                isCosTurn = true;
                Monitor.Pulse(sync); 
            }
            Thread.Sleep(500); 
        }
    }
}