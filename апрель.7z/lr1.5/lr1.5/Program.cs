﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;

class Program
{
    static async Task Main()
    {
        var discipline = new Discipline("Математика");
        var students = new List<Student>
        {
            new Student("Иванов", new List<double> { 4, 5, 3, 4 }),
            new Student("Петров", new List<double> { 3, 4, 5, 4 }),
            new Student("Сидоров", new List<double> { 5, 5, 5, 5 }),
            new Student("Кузнецов", new List<double> { 3, 3, 4, 4 }),
            new Student("Смирнов", new List<double> { 4, 4, 4, 4 })
        };

        discipline.AddStudents(students);

        var syncStopwatch = Stopwatch.StartNew();
        var syncAvg = discipline.CalculateAverageGradeSync();
        syncStopwatch.Stop();
        Console.WriteLine($"Синхронный метод: средняя оценка = {syncAvg:F2}, время = {syncStopwatch.ElapsedMilliseconds} мс");

        var asyncStopwatch = Stopwatch.StartNew();
        var asyncAvg = await discipline.CalculateAverageGradeAsync();
        asyncStopwatch.Stop();
        Console.WriteLine($"Асинхронный метод: средняя оценка = {asyncAvg:F2}, время = {asyncStopwatch.ElapsedMilliseconds} мс");
    }
}

class Discipline
{
    public string Name { get; }
    private List<Student> Students { get; } = new List<Student>();

    public Discipline(string name)
    {
        Name = name;
    }

    public void AddStudents(IEnumerable<Student> students)
    {
        Students.AddRange(students);
    }

    public double CalculateAverageGradeSync()
    {
        double sum = 0;
        int count = 0;

        foreach (var student in Students)
        {
            foreach (var grade in student.Grades)
            {
                sum += grade;
                count++;
                Thread.Sleep(10);
            }
        }

        return count > 0 ? sum / count : 0;
    }

    public async Task<double> CalculateAverageGradeAsync()
    {
        var tasks = Students.Select(async student =>
        {
            double sum = 0;
            int count = 0;

            foreach (var grade in student.Grades)
            {
                sum += grade;
                count++;
                await Task.Delay(10);
            }

            return (sum, count);
        });

        var results = await Task.WhenAll(tasks);
        var totalSum = results.Sum(r => r.sum);
        var totalCount = results.Sum(r => r.count);

        return totalCount > 0 ? totalSum / totalCount : 0;
    }
}

class Student
{
    public string LastName { get; }
    public List<double> Grades { get; }
    public Student(string lastName, List<double> grades)
    {
        LastName = lastName;
        Grades = grades;
    }
}